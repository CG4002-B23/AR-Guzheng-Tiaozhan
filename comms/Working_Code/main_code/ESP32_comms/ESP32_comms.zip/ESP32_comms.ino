#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <WiFiClientSecure.h>
#include "config.h"
#include "CSV_DATA.h"

// ============================================================================
// CONFIGURATION
// ============================================================================
const char* ssid = "iPhone (67)";
const char* password = "12345qwert";
const char* mqtt_broker = "172.20.10.4";
const int mqtt_port = 8883;

IPAddress local_IP(172, 20, 10, 2);
IPAddress gateway(172, 20, 10, 1);
IPAddress subnet(255, 255, 255, 0);
IPAddress dns(8, 8, 8, 8);

const char* TOPIC_SEND = "esp32/scan";
const char* TOPIC_RECEIVE = "laptop/to_esp32/FB_001";

WiFiClientSecure espClient;
PubSubClient client(espClient);

#define DEVICE_ID "FB_001"

// ============================================================================
// GLOBAL VARIABLES
// ============================================================================
int currentSampleIndex = 0;
int batchCounter = 0;
const int SAMPLES_PER_BATCH = 30;

// Buffer for collecting samples
#define MAX_BATCH_SIZE 30
CSVSample sampleBuffer[MAX_BATCH_SIZE];
int samplesInBuffer = 0;

unsigned long lastSampleTime = 0;
const unsigned long SAMPLE_INTERVAL_US = 30000;  // 100Hz = 10ms

bool wifiConnected = false;
bool mqttConnected = false;
unsigned long lastReconnectAttempt = 0;
const unsigned long RECONNECT_INTERVAL = 5000;

// Simple counters for debug output
unsigned long totalBatchesSent = 0;
unsigned long loopCount = 0;

//send control flag
bool streamEnabled = false;

void handleTriggerMessage(const JsonDocument& doc) {
  Serial.println("Handling trigger message...");
  
  if (doc.containsKey("target_device")) {
    const char* target = doc["target_device"];
    Serial.printf("Target device: %s, My device: %s\n", target, DEVICE_ID);
    
    if (strcmp(target, DEVICE_ID) == 0) {
      if (doc.containsKey("action")) {
        const char* action = doc["action"];
        Serial.printf("Action: %s\n", action);
        
        if (strcmp(action, "start") == 0) {
          streamEnabled = true;
          Serial.printf("\n*** STREAM ENABLED for %s ***\n", DEVICE_ID);
        } else if (strcmp(action, "stop") == 0) {
          streamEnabled = false;
          Serial.printf("\n*** STREAM DISABLED for %s ***\n", DEVICE_ID);
        }
      }
    }
  }
}

// ============================================================================
// DATA SENDING FUNCTIONS
// ============================================================================
void sendBatch() {
  if (samplesInBuffer == 0) return;
  
  bool canSend = (WiFi.status() == WL_CONNECTED && client.connected() && streamEnabled);
  
  if (canSend) {
    StaticJsonDocument<16384> doc;
    String batchId = "BATCH_" + String(++batchCounter);
    
    doc["device_id"] = DEVICE_ID;
    doc["batch_id"] = batchId;
    doc["batch_size"] = samplesInBuffer;
    doc["start_index"] = currentSampleIndex - samplesInBuffer;
    
    JsonArray samplesArray = doc.createNestedArray("samples");
    
    for (int i = 0; i < samplesInBuffer; i++) {
      JsonObject sample = samplesArray.createNestedObject();
      
      JsonArray flexArray = sample.createNestedArray("flex");
      for (int f = 0; f < 5; f++) {
        flexArray.add(sampleBuffer[i].flex[f]);
      }
      
      JsonArray accArray = sample.createNestedArray("acc");
      for (int a = 0; a < 3; a++) {
        accArray.add(sampleBuffer[i].acc[a]);
      }
      
      sample["label"] = sampleBuffer[i].label;
    }
    
    String output;
    serializeJson(doc, output);
    
    if (client.publish(TOPIC_SEND, output.c_str())) {
      totalBatchesSent++;
      Serial.printf("Sent batch %d (%d samples, index %d)\n", 
                    batchCounter, samplesInBuffer, currentSampleIndex - samplesInBuffer);
      
      digitalWrite(2, !digitalRead(2));
      samplesInBuffer = 0;
    }
  } else {
    // Just drop the batch when disconnected or disabled
    samplesInBuffer = 0;
  }
}

void addSampleToBuffer(const CSVSample& sample) {
  if (samplesInBuffer < MAX_BATCH_SIZE) {
    sampleBuffer[samplesInBuffer++] = sample;
  }
  
  if (samplesInBuffer >= MAX_BATCH_SIZE) {
    sendBatch();
  }
}

CSVSample getNextSample() {
  CSVSample sample = csvSamples[currentSampleIndex];
  
  currentSampleIndex++;
  if (currentSampleIndex >= CSV_TOTAL_SAMPLES) {
    currentSampleIndex = 0;
    loopCount++;
    Serial.printf("Completed loop %lu, total batches sent: %lu\n", loopCount, totalBatchesSent);
  }
  
  return sample;
}

// ============================================================================
// CONNECTION MANAGEMENT
// ============================================================================
void checkWiFi() {
  wifiConnected = (WiFi.status() == WL_CONNECTED);
  
  if (!wifiConnected) {
    WiFi.begin(ssid, password);
  }
}

void checkMQTT() {
  if (wifiConnected && !client.connected()) {
    mqttConnected = false;
    
    unsigned long now = millis();
    if (now - lastReconnectAttempt > RECONNECT_INTERVAL) {
      lastReconnectAttempt = now;
      
      Serial.print("Connecting to MQTT...");
      String clientId = String(DEVICE_ID) + String(random(0xffff), HEX);
      
      if (client.connect(clientId.c_str())) {
        mqttConnected = true;
        Serial.println("connected");
        client.subscribe(TOPIC_RECEIVE);
        
        StaticJsonDocument<128> connMsg;
        connMsg["device_id"] = DEVICE_ID;
        connMsg["packet_type"] = "CONNECT";
        
        String output;
        serializeJson(connMsg, output);
        client.publish(TOPIC_SEND, output.c_str());
      } else {
        Serial.printf("failed, rc=%d\n", client.state());
      }
    }
  } else if (wifiConnected && client.connected()) {
    mqttConnected = true;
  } else {
    mqttConnected = false;
  }
}

// ============================================================================
// WIFI AND MQTT SETUP
// ============================================================================
void setup_wifi() {
  if (!WiFi.config(local_IP, gateway, subnet, dns)) {  
      Serial.println("Static ip failed!");
  } else {
      Serial.print("Static IP configured: ");
      Serial.println(local_IP);
  }
  Serial.print("Connecting to WiFi");
  WiFi.begin(ssid, password);
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected");
    wifiConnected = true;
  } else {
    Serial.println("\nWiFi connection failed");
    wifiConnected = false;
  }
}

void setup_tls() {
  espClient.setCACert(ca_cert);
  espClient.setCertificate(client_cert);
  espClient.setPrivateKey(client_key);
}

// ============================================================================
// MQTT CALLBACK
// ============================================================================
void mqtt_callback(char* topic, byte* payload, unsigned int length) {
  Serial.printf("Message received on topic: %s\n", topic);
  
  StaticJsonDocument<1024> doc;
  DeserializationError error = deserializeJson(doc, payload, length);
  
  if (error) {
    Serial.print("Failed to parse MQTT message: ");
    Serial.println(error.c_str());
    return;
  }
  
  // Print the received message for debugging
  Serial.print("Message content: ");
  serializeJson(doc, Serial);
  Serial.println();
  
  // Check if it's a trigger message (case insensitive check)
  if (strcmp(topic, TOPIC_RECEIVE) == 0) {
    // Handle if it has type field
    if (doc.containsKey("type")) {
      const char* msgType = doc["type"];
      if (strcmp(msgType, "trigger") == 0 || strcmp(msgType, "TRIGGER") == 0) {
        handleTriggerMessage(doc);
      }
    }
    
    // Also handle if it has target_device field directly
    if (doc.containsKey("target_device")) {
      handleTriggerMessage(doc);
    }
  }
  
  digitalWrite(2, !digitalRead(2));
}

// ============================================================================
// SETUP AND MAIN LOOP
// ============================================================================
void setup() {
  Serial.begin(115200);
  delay(1000);
  
  pinMode(2, OUTPUT);
  digitalWrite(2, LOW);
  
  Serial.printf("CSV Data: %d samples loaded\n", CSV_TOTAL_SAMPLES);
  Serial.printf("Sending at 100Hz, %d samples per batch\n", SAMPLES_PER_BATCH);
  Serial.printf("Initial stream state: %s\n", streamEnabled ? "ENABLED" : "DISABLED");
  
  setup_wifi();
  setup_tls();
  
  client.setClient(espClient);
  client.setServer(mqtt_broker, mqtt_port);
  client.setCallback(mqtt_callback);
  client.setBufferSize(16384);
  client.setKeepAlive(60);
  
  if (wifiConnected) {
    checkMQTT();
  }
  
  lastSampleTime = micros();
  lastReconnectAttempt = millis();
  
  Serial.println("Started");
}

void loop() {
  checkWiFi();
  checkMQTT();
  
  if (mqttConnected) {
    client.loop();
  }
  
  unsigned long now = micros();
  
  if ((now - lastSampleTime) >= SAMPLE_INTERVAL_US) {
    CSVSample sample = getNextSample();
    addSampleToBuffer(sample);
    lastSampleTime = now;
  }
  
  delay(1);
}
